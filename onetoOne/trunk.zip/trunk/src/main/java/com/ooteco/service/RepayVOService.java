package com.ooteco.service;

import java.util.Date;

/**
 * Created by zk on 2017/8/30.
 */
public interface RepayVOService {
    
}
