package com.ooteco.utils;

/**
 * Created by zk on 2017/8/28.
 */
public class SecretKey {
    public static String SECRETKEY = "78D4037B9D74CC978B518076ADEFFA38";
}
