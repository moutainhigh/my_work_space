package com.ooteco.controllers;

/**
 * Created by zk on 2017/8/3.
 */
public class ForeignController {

}
