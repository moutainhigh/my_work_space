package com.ooteco.service;

import java.util.Date;

public interface FinanceLoanSplitVOService {

    void insert(Date date);
}
