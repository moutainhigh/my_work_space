package com.ooteco.dao.mapper.ext;

import java.math.BigDecimal;

public interface LoanVOExtMapper {

    BigDecimal getCurrentTotalAmount();
}