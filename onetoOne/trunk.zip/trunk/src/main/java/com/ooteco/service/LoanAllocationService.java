package com.ooteco.service;

import com.ooteco.entity.loanAllocation.model.LoanAllocation;

/**
 * Created by zk on 2017/7/26.
 */
public interface LoanAllocationService {
    void insert(LoanAllocation loanAllocation);
}
