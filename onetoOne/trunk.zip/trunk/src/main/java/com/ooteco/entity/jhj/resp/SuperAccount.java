package com.ooteco.entity.jhj.resp;

import java.math.BigDecimal;

public class SuperAccount {

    public BigDecimal balance;
    public String userCode;
}
