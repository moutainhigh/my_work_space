package com.ooteco.entity.loan.model.resp;

import java.math.BigDecimal;

public class LoanFullScaleDetail {

    public String userCode;
    public BigDecimal loanMoney;
    public String matchTime;
    public String interest;
    public String startDate;
    public String endDate;
    public int financeProductsId;
    public String financeCode;
}
