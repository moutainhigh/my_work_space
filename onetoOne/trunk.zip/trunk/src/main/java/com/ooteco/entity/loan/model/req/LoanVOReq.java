package com.ooteco.entity.loan.model.req;

import com.ooteco.entity.loan.model.LoanVO;
import com.ooteco.entity.req.BaseReq;
import org.springframework.format.annotation.DateTimeFormat;

import javax.validation.Valid;
import java.util.Date;

/**
 * Created by zk on 2017/8/29.
 */
public class LoanVOReq extends LoanVO {
}
